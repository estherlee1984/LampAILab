
import React, { useEffect } from 'react'

export default function App() {
  useEffect(() => {
    document.body.style.backgroundColor = 'black';
  }, [])

  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>LampAI Lab</h1>
      <p>探索超级生物智能的第一性原理</p>
    </div>
  )
}
